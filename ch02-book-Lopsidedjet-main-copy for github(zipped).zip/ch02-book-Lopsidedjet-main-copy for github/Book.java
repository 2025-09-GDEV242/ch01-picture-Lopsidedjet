/**
 * A class that maintains information on a book.
 * This might form part of a larger application such
 * as a library system, for instance.
 *
 *I feel emabruised for this but used a little chatBT, but only to see
 *what was wrong with code, no copyand paste 
 * @author (Joseph Pattie.)
 * @version (9/18/2025.)
 * 2.86 = without settlers, the books objects is immuntable as of this 
 * question
 */
class Book
{
    // The fields.
    private String author;
    private String title;
    private int pages;
    private String refNumber; 
    private int borrowed;
    private boolean courseText;

    /**
     * Set the author and title fields when this object
     * is constructed.
     */
    public Book(String bookAuthor, String bookTitle, int pageAmount, boolean 
    isText)
    {
        author = bookAuthor;
        title = bookTitle;
        pages = pageAmount;
        refNumber = "";
        borrowed = 0;
        courseText = isText; 
    }

    /**
     * gettor for boolean course text
     */
    public boolean isCourseText()
    {
        return courseText;
    }
    
    
    public void borrow()
    {
    borrowed = borrowed + 1; 
}
    

public int getBorrowed()
    {
     return borrowed;
}
    
    /**
     * make mutatto for refnumber
     * ? add get lenght here
     */
    public void setRefNumber(String ref)
    {
        if(ref.length() >= 3)
        {
        refNumber = ref;}

    
        else 
        {
            System.out.println( "error need to be 3 or longer");
        }
    
        
    }
    
    /**
     * make gettor for refnumber called getrefNumber
     * remember gettor dont have paremeters
     */
    public String getRefNumber()
    {
        return refNumber; 
    }
    
    /**
     * make method fro author and book name 
     */
    public String getAuthor()
    {
        return author;
    }
    
    /**
     * make method  book name 
     */
    public String getTitle()
    {
        return title;
    }

    /**
     * make method for pages
     */
    public int getPages()
    {
        return pages;
    }
    
    
     /**
     * make print author method
     */
    public void printAuthor()
    {
        System.out.println(author);
    }
    
    /**
     * make print author method
     */
    public void printTitle()
    {
        System.out.println(title);
    }
    
    
    
    /**
     * Add . length here to if also a ; end an if premature
     */
    public void printDetails()

    {
    if(refNumber.length() > 0)
        {
        System.out.println( "The order is title then author then page count");
        System.out.println( " The book is called " + title); 
        System.out.println (" its by " + author);
        System.out.println( " and it page count is " +pages);
        System.out.println( " its reference number is " + 
        refNumber + " it been borrowed " + borrowed);

    }
    else
     {
        System.out.println( "The order is title then author then page count");
        System.out.println( " The book is called " + title); 
        System.out.println (" its by " + author);
        System.out.println( " and it page count is " +pages);
        System.out.println( " its reference number is " + 
        "ZZZ" + " it been borrowed " + borrowed);

    }
    }
    
}
